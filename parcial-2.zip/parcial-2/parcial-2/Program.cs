﻿using Microsoft.VisualBasic;
using System.Diagnostics.Metrics;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
namespace parcial_2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            /*El director de la escuela “Herederos” desea conocer información estadística sobre las edades de los estudiantes del grado quinto A, que cuenta con 15 alumnos.
            El programa debe realizar las siguientes acciones:
            Ingresar por teclado la edad de cada estudiante(solo se permiten valores de 4, 5 o 6 años).
            Calcular el promedio de edad del grupo.
            Contar y mostrar cuántos estudiantes tienen 4 años, cuántos tienen 5 años y cuántos tienen 6 años.
            Comparar las cantidades y mostrar un mensaje especial:
            Si el número de estudiantes de 6 años es mayor que el de los demás, mostrar: “Grupo mayor”.
            Si el número de estudiantes de 4 años es mayor que el de los demás, mostrar: “Grupo menor”.*/

            int totalEstudiantes = 15;
            int contador = 1;
            int sumaEdades = 0;

            int edad4 = 0;
            int edad5 = 0;
            int edad6 = 0;

            Console.WriteLine("Bienvenido director, ingresa por favor la edad de los 15 estudiantes del grado quinto A");

            while (contador <= totalEstudiantes)
            {
                Console.WriteLine("Ingrese la edad del estudiante " + contador + " (4, 5 o 6): ");
                int edad = int.Parse(Console.ReadLine());

                if (edad == 4)
                {
                    edad4++;
                    sumaEdades += edad;
                    contador++;
                }
                else if (edad == 5)
                {
                    edad5++;
                    sumaEdades += edad;
                    contador++;
                }
                else if (edad == 6)
                {
                    edad6++;
                    sumaEdades += edad;
                    contador++;
                }
                else
                {
                    Console.WriteLine(" Edad inválida, solo se permiten 4, 5 o 6 años.");
                }
            }

            
            double promedio = (double)sumaEdades / totalEstudiantes;


            
            Console.WriteLine("\n Resultados de las edades de los estudiantes ");
            Console.WriteLine("Promedio de edad: " + promedio);
            Console.WriteLine("Cantidad de estudiantes de 4 años: " + edad4);
            Console.WriteLine("Cantidad de estudiantes de 5 años: " + edad5);
            Console.WriteLine("Cantidad de estudiantes de 6 años: " + edad6);

            Console.WriteLine("Perfecto, una vez viendo esto, podras ver que:");


            if (edad6 > edad4 && edad6 > edad5)
            {
                Console.WriteLine("Al ser mayor la cantidad de 6 años, es Grupo mayor");
            }
            else if (edad4 > edad5 && edad4 > edad6)
            {
                Console.WriteLine("Al ser mayor la cantidad de 4 años, esGrupo menor");
            }
            else
            {
                Console.WriteLine("Al ser mayor los 5 años no es ni grupo mayor ni grupo menor");
                    
             }
        }
    }
}
